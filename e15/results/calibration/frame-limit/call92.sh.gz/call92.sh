(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=0 RC=$__rc" >&2; exit 90; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=1 RC=$__rc" >&2; exit 91; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=2 RC=$__rc" >&2; exit 92; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=3 RC=$__rc" >&2; exit 93; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=4 RC=$__rc" >&2; exit 94; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=5 RC=$__rc" >&2; exit 95; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=6 RC=$__rc" >&2; exit 96; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=7 RC=$__rc" >&2; exit 97; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=8 RC=$__rc" >&2; exit 98; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=9 RC=$__rc" >&2; exit 99; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=10 RC=$__rc" >&2; exit 100; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=11 RC=$__rc" >&2; exit 101; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=12 RC=$__rc" >&2; exit 102; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=13 RC=$__rc" >&2; exit 103; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=14 RC=$__rc" >&2; exit 104; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=15 RC=$__rc" >&2; exit 105; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=16 RC=$__rc" >&2; exit 106; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=17 RC=$__rc" >&2; exit 107; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=18 RC=$__rc" >&2; exit 108; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=19 RC=$__rc" >&2; exit 109; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=20 RC=$__rc" >&2; exit 110; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=21 RC=$__rc" >&2; exit 111; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=22 RC=$__rc" >&2; exit 112; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=23 RC=$__rc" >&2; exit 113; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=24 RC=$__rc" >&2; exit 114; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=25 RC=$__rc" >&2; exit 115; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=26 RC=$__rc" >&2; exit 116; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=27 RC=$__rc" >&2; exit 117; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=28 RC=$__rc" >&2; exit 118; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=29 RC=$__rc" >&2; exit 119; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=30 RC=$__rc" >&2; exit 120; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=31 RC=$__rc" >&2; exit 121; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=32 RC=$__rc" >&2; exit 122; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=33 RC=$__rc" >&2; exit 123; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=34 RC=$__rc" >&2; exit 124; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=35 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=36 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=37 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=38 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=39 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=40 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=41 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=42 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=43 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=44 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=45 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=46 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=47 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=48 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=49 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=50 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=51 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=52 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=53 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=54 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=55 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=56 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=57 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=58 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=59 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=60 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=61 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=62 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=63 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=64 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=65 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=66 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=67 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=68 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=69 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=70 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=71 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=72 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=73 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=74 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=75 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=76 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=77 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=78 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=79 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=80 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=81 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=82 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=83 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=84 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=85 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=86 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=87 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=88 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=89 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=90 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=91 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=92 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=93 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=94 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=95 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=96 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=97 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=98 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=99 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=100 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=101 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=102 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=103 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=104 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=105 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=106 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=107 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=108 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=109 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=110 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=111 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=112 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=113 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=114 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=115 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=116 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=117 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=118 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=119 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=120 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=121 RC=$__rc" >&2; exit 125; }
(
cd project && rm -rf .e15/tar && mkdir -p .e15/tar && python3 -m tarfile -c .e15/tar/p.tgz more_itertools tests docs && python3 -m tarfile -e .e15/tar/p.tgz .e15/tar/x && rm -rf .e15/tar
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=122 RC=$__rc" >&2; exit 125; }
(
cd project && for i in $(seq 20); do rm -rf .e15/copy && mkdir -p .e15/copy && cp -r more_itertools tests docs .git .e15/copy/; done && rm -rf .e15/copy
); __rc=$?; [ "$__rc" -eq 0 ] || { echo "E15_FAILED_STEP=123 RC=$__rc" >&2; exit 125; }
exit 0
